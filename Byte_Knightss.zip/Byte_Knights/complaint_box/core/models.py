# Create your models here.
from django.db import models

import uuid

class Complaint(models.Model):

    tracking_id = models.CharField(max_length=12, unique=True, editable=False)
    

    subject = models.CharField(max_length=200)
    department = models.CharField(max_length=100, blank=True)
    user_type = models.CharField(max_length=30)  
    complaining_against = models.TextField(blank=True) 
    student_branch = models.CharField(max_length=100, blank=True)
    category = models.CharField(max_length=50)
    urgency_level = models.CharField(max_length=20)
    complaint_description = models.TextField()

    status = models.CharField(max_length=20, default="submitted")  
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if not self.tracking_id:
            self.tracking_id = uuid.uuid4().hex[:10].upper()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.tracking_id} - {self.subject}"
