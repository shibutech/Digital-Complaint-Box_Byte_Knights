from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.contrib.auth.models import User
from .models import Complaint

def home(request):
    return render(request, "index.html")

def submit_complaint(request):
    if request.method == "POST":
        
        subject = request.POST.get("subject", "").strip()
        department = request.POST.get("department", "").strip()
        user_type = request.POST.get("user_type", "").strip()
        complaining_list = request.POST.getlist("complainingDepartment[]")
        complaining_against = ", ".join(complaining_list)
        student_branch = request.POST.get("student_branch", "").strip()
        category = request.POST.get("category", "").strip()
        urgency = request.POST.get("urgency_level", "").strip()
        desc = request.POST.get("complaint_description", "").strip()

        if not (subject and user_type and category and urgency and desc):
            messages.error(request, "Please fill all required fields.")
            return render(request, "complaint.html")

        obj = Complaint.objects.create(
            subject=subject,
            department=department,
            user_type=user_type,
            complaining_against=complaining_against,
            student_branch=student_branch,
            category=category,
            urgency_level=urgency,
            complaint_description=desc,
        )
        return render(request, "success.html", {"complaint_id": obj.tracking_id})

    return render(request, "complaint.html")

def track_page(request):
    if request.method == "POST":
        tid = request.POST.get("complaintId", "").strip().upper()
        if not tid:
            messages.error(request, "Enter a valid Complaint ID.")
            return render(request, "track.html")

        try:
            c = Complaint.objects.get(tracking_id=tid)
            return render(request, "track.html", {"result": c})
        except Complaint.DoesNotExist:
            messages.error(request, "No complaint found for this ID.")
            return render(request, "track.html")

    return render(request, "track.html")

@login_required
def dashboard(request):
    qs = Complaint.objects.order_by("-created_at")
    return render(request, "dashboard.html", {"complaints": qs})

@login_required
@require_POST

def update_status(request, tracking_id):
    complaint = get_object_or_404(Complaint, tracking_id=tracking_id)

    if request.method == "POST":
        new_status = request.POST.get("status")
        complaint.status = new_status
        complaint.save()
        messages.success(request, f"Complaint {complaint.tracking_id} status updated to {new_status}")
        return redirect("dashboard") 

def admin_login(request):
    if request.method == "POST":
        username = request.POST.get("name")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect("dashboard")
        else:
            messages.error(request, "Invalid username or password")
    return render(request, "login.html")


def admin_signup(request):
    if request.method == "POST":
        name = request.POST.get("name", "").strip()
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password", "").strip()
        
        if not (name and email and password):
            messages.error(request, "All fields are required")
            return render(request, "signup.html")
        
        if User.objects.filter(username=name).exists():
            messages.error(request, "Username already exists")
            return render(request, "signup.html")
        
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already exists")
            return render(request, "signup.html")
        
        user = User.objects.create_user(username=name, email=email, password=password)
        user.save()   # 👈 important
        messages.success(request, "Account created successfully! Please login.")
        return redirect("login")
    
    return render(request, "signup.html")


def admin_logout(request):
    logout(request)
    return redirect("home")
