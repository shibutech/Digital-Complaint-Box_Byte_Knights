from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('complaint/', views.submit_complaint, name='complaint'),
    path('track/', views.track_page, name='track'),
    path('login/', views.admin_login, name='login'),
    path('signup/', views.admin_signup, name='signup'),
    path('logout/', views.admin_logout, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('update-status/<str:tracking_id>/', views.update_status, name='update_status'),
]
