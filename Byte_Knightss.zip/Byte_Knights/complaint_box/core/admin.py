
from django.contrib import admin
from .models import Complaint

@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ("tracking_id", "subject", "department", "category", "urgency_level", "status", "created_at")
    list_filter = ("status", "department", "category", "urgency_level", "created_at")
    search_fields = ("tracking_id", "subject", "complaint_description")

# admin.site.register(Complaint)
